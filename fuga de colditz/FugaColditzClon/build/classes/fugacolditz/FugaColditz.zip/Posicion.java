package fugacolditz;
public class Posicion {
       
    int x;
    int y;
    
    public Posicion (int x, int y){
        this.x=x;
        this.y=y;
    }
}
